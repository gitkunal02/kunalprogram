"""
URL configuration for hospital project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path,include
from hospitalapp import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.login, name='login'),
    path('signup/login/',views.login, name='login'),
    path('signup/',views.signup, name='signup'),
    path('home/',views.home, name='home'),
    path('login/home/',views.home, name='home'),

    path('addpatient/',views.addpatient,name='addpatient'),
    path('allpatient/',views.allpatient, name='allpatient'),
    path('delete/<int:id>',views.delete,name='delete'),
    path('edit/<int:id>',views.edit,name='edit'),
    path('patient_information/<int:id>',views.patient_information,name='patient_information'),



    path('adddoctore/',views.adddoctore, name='adddoctore'),
    path('alldoctore/',views.alldoctore, name='alldoctore'),
    path('deletedoctore/<int:id>',views.deletedoctore,name='delete'),
    path('editdoctore/<int:id>',views.editdoctore,name='edit'),
    path('doctore_information/<int:id>',views.doctore_information,name='doctore_information'),


    
    path('addaportment/',views.addaportment, name='addaportment'),
    path('allaportment/',views.allaportment, name='allaportment'),
    path('deleteaportment/<int:id>',views.deleteaportment,name='deleteaportment'),
    path('editaportment/<int:id>',views.editaportment,name='edit'),
    


    path('payment/',views.payments,name='payment'),
    path('allpayment/',views.allpayment, name='allpayment'),
    path('deletepament/<int:id>',views.deletepament,name='deletepament'),
    


 ]