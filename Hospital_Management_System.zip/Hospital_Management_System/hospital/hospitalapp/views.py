from django.shortcuts import render,redirect
from django.http import HttpResponse,HttpResponseRedirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login as authloging,logout
from .models import Patient,payment,doctor,apportmentss
from django.contrib.auth.decorators import login_required
@login_required(login_url='login')
# Create your views here.

def home(request):
    return render(request, 'homepage.html')


def signup(request):
    if  request.method == 'POST':
        username = request.POST.get('username')
        email =request.POST.get('email')
        password1 = request.POST.get('password1')
        password2= request.POST.get('password2')
        
        if password1 != password2:
            return HttpResponse("Invalid password")
        else:

            myuser = User.objects.create_user( username, email,password2)
            myuser.save()

            return HttpResponseRedirect('login/')
    return render(request,'signup.html')


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password2')
        user=authenticate(request,username=username,password=password)
        if user is not None:
            authloging(request,user)
            return redirect('/home')
        else:
            return redirect('/home')
        
    return render(request,'loging.html')


#### add patient
def addpatient(request):
    if request.method == 'POST':
        patient_name = request.POST.get('patient_name')
        date_of_birth = request.POST.get('dob')
        age = request.POST.get('age')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        address = request.POST.get('address')

        patient = Patient(
            patient_Name = patient_name,
            date_of_birth = date_of_birth,
            age = age,
            phone = phone,
            email = email,
            gender = gender,
            address = address,
        ) 
        patient.save()
        return redirect('/allpatient')   
    return render(request,'addpatient.html')


### all patient view
def allpatient(request):
    patientdata=Patient.objects.all()

    data={
        'patientdata':patientdata
    }
    return render(request,'allpatient.html',data)


##### for edit and delete
def delete(rquest,id):
    dele=Patient.objects.get(id=id)
    dele.delete()
    return redirect('/allpatient')

def edit(request,id):
    editdata=Patient.objects.get(id=id)
    if request.method == 'POST':
        patient_name = request.POST.get('patient_name')
        date_of_birth = request.POST.get('dob')
        age = int(request.POST.get('age'))
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        address = request.POST.get('address')

        editdata = Patient(
            patient_Name = patient_name,
            date_of_birth = date_of_birth,
            age = age,
            phone = phone,
            email = email,
            gender = gender,
            address = address,
            id=id
        )

        editdata.save()
        return redirect('/allpatient')
    else:
        editdata={
            "editdata":editdata
        }
        return render(request,'patientedit.html',editdata)


### patient information
def patient_information(request,id):
    editdata=Patient.objects.get(id=id)
    editdata={
        "editdata":editdata
    }
    return render(request,'Patientinformation.html',editdata)

def Apportmant_information(request,id):
    editdata=apportmentss.objects.get(id=id)
    editdata={
        "editdata":editdata
    }
    return render(request,'Patientinformation.html',editdata)


### make payment

def payments(request):
    if request.method == 'POST':
        Patient_iD = request.POST.get('patient_iD')
        patient_Name = request.POST.get('patient_Name')
        dipartment = request.POST.get('dipartment')
        doctor_name = request.POST.get('doctor_name')
        appointment_date = request.POST.get('appointment_date')
        Discharge_date = request.POST.get('Discharge_date')
        service_name = request.POST.get('service_name')
        Cost = request.POST.get('Cost')
        discount = request.POST.get('discoun')
        payment_type = request.POST.get('payment_type')
        card_check_no = request.POST.get('card_check_no')

        payments=payment(
            patient_iD=Patient_iD,
            patient_Name=patient_Name,
            dipartment= dipartment,
            doctor_name=doctor_name,
            appointment_date=appointment_date,
            Discharge_date=Discharge_date,
            service_name=service_name,
            Cost=Cost,
            discount=discount,
            payment_type=payment_type,
            card_check_no=card_check_no

        ) 
        payments.save()
        return redirect('/home')
      
    return render(request,'Add_pament.html')


def allpayment(request):
    paymentdata=payment.objects.all()
    data={
        'paymentdata':paymentdata
    }
    return render(request,'allpayment.html',data)


def deletepament(rquest,id):
    dele=payment.objects.get(id=id)
    dele.delete()
    return redirect('/allpayment')






### add doctor
def adddoctore(request):
    if request.method == 'POST':
        doctor_name = request.POST.get('doctor_name')
        date_of_birth = request.POST.get('date_of_birth')
        spacilaization = request.POST.get('spacilaization')
        exprience = request.POST.get('exprience')
        age = request.POST.get('age')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        doctor_details = request.POST.get('doctor_details')
        address = request.POST.get('address')
        # profile_pic = request.POST.get('profile_pic')
        

        doctore= doctor(
           doctor_name=doctor_name,
           date_of_birth=date_of_birth,
           spacilaization=spacilaization,
           exprience=exprience,
           age=age,
           phone=phone,
           email=email,
           gender=gender,
           doctor_details=doctor_details,
           address=address,
        #    profile_pic=profile_pic
        ) 
        doctore.save()
        return redirect('/alldoctore')

    return render(request,'adddoctor.html')

def alldoctore(request):
    doctoredata=doctor.objects.all()

    data={
        'doctoretdata':doctoredata
    }
    return render(request,'alldoctore.html',data)

def doctor_information(request,id):
    editdata=doctor.objects.get(id=id)
    editdata={
        "editdata":editdata
    }
    return render(request,'doctoreinformation.html',editdata)


def deletedoctore(rquest,id):
    dele=doctor.objects.get(id=id)
    dele.delete()
    return redirect('/alldoctore')

def editdoctore(request,id):
    editdata=doctor.objects.get(id=id)
    if request.method == 'POST':
        doctor_name = request.POST.get('doctor_name')
        date_of_birth = request.POST.get('date_of_birth')
        exprience = int(request.POST.get('exprience'))
        age = int(request.POST.get('age'))
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        gender = request.POST.get('gender')
        # doctor_details = request.POST.get('doctor_details')
        address = request.POST.get('address')
        spacilaization = request.POST.get('spacilaization')

        editdata= doctor(
           id=id,
           doctor_name=doctor_name,
           date_of_birth=date_of_birth,
           exprience=exprience,
           age=age,
           phone=phone,
           email=email,
           gender=gender,
        #    doctor_details=doctor_details,
           address=address,
           spacilaization=spacilaization,
        )
        editdata.save()
        return redirect('/alldoctore')
    else:
        editdata={
            "editdata":editdata
        }
        return render(request,'doctoredit.html',editdata)


def doctore_information(request,id):
    editdata=doctor.objects.get(id=id)
    editdata={
        "editdata":editdata
    }
    return render(request,'doctoreinformation.html',editdata)


#### add apportmentss
def addaportment(request):
    if request.method == 'POST':
        Patient_Name = request.POST.get('Patient_Name')
        dipartment = request.POST.get('dipartment')
        appointment_date = request.POST.get('appointment_date')
        doctor_name = request.POST.get('doctor_name')
        time_slot = request.POST.get('time_slot')
        token = request.POST.get('token')
        problems = request.POST.get('problems')

        
        aportment= apportmentss(
            Patient_Name=Patient_Name,
            dipartment=dipartment,
            appointment_date=appointment_date,
            doctor_name=doctor_name,
            time_slot=time_slot,
            token=token,
            problems=problems
        )
        aportment.save()
        return redirect('/allaportment')

    return render(request,'addaportment.html')

def allaportment(request):
    aportmentdata=apportmentss.objects.all()

    data={
        'aportmenttdata':aportmentdata
    }
    return render(request,'allaportment.html',data)


def deleteaportment(rquest,id):
    dele=apportmentss.objects.get(id=id)
    dele.delete()
    return redirect('/allaportment')

def editaportment(request,id):
    editdata=apportmentss.objects.get(id=id)
    if request.method == 'POST':
        Patient_Name = request.POST.get('Patient_Name')
        dipartment = request.POST.get('dipartment')
        appointment_date = request.POST.get('appointment_date')
        doctor_name = request.POST.get('doctor_name')
        time_slot = request.POST.get('time_slot')
        token = request.POST.get('token')
        problems = request.POST.get('problems')

        editdata = apportmentss(
            id=id,
            Patient_Name=Patient_Name,
            dipartment=dipartment,
            appointment_date=appointment_date,
            doctor_name=doctor_name,
            time_slot=time_slot,
            token=token,
            problems=problems,
        )

        editdata.save()
        return redirect('/allaportment')
    else:
        editdata={
            "editdata":editdata
        }
        return render(request,'aportmentedit.html',editdata)



