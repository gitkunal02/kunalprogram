from django.contrib import admin
from hospitalapp.models import Patient,apportmentss,doctor,payment

###for pdf

# from reportlab.pdfgen import canvas
# from reportlab.lib.pagesizes import text
# from reportlab.platypus import Table,TableStyle
# from reportlab.lib import colors
# Register your models here.

admin.site.register(Patient)

admin.site.register(apportmentss)

admin.site.register(payment)

admin.site.register(doctor)


#admin.site.register(Doctor) # If you want to add Doctor model in admin panel.




