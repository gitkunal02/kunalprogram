from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

# Create your models here.

class Patient(models.Model):
    patient_Name = models.CharField(max_length=100)
    date_of_birth = models.CharField(max_length=20)
    age = models.IntegerField()
    phone = models.CharField(max_length=12)
    email = models.CharField(max_length=100)
    gender = models.CharField(max_length=50)
    address = models.TextField()

    def __str__(self):
        return self.patient_Name
    
class apportmentss (models.Model):
    Patient_Name = models.CharField(max_length=100,)
    dipartment = models.CharField(max_length=50)
    appointment_date = models.CharField(max_length=50)
    doctor_name = models.CharField(max_length=50)
    time_slot = models.CharField(max_length=50)
    token = models.IntegerField()
    problems = models.CharField(max_length=50)
    
    def __str__(self):
        return self.Patient_Name
    

class payment(models.Model):
    patient_iD = models.IntegerField()
    patient_Name = models.CharField(max_length=100)
    dipartment = models.CharField(max_length=50)
    doctor_name = models.CharField(max_length=50)
    appointment_date = models.DateField(max_length=50)
    Discharge_date = models.DateField(max_length=50)
    service_name = models.CharField(max_length=50)
    Cost = models.CharField(max_length=50)
    discount = models.CharField(max_length=50,null=True)
    payment_type = models.CharField(max_length=50)
    card_check_no = models.CharField(max_length=50)

    def __str__(self):
        return self.patient_Name
    


class doctor(models.Model):
    doctor_name = models.CharField(max_length=50)
    date_of_birth = models.CharField(max_length=50)
    spacilaization = models.CharField(max_length=100)
    exprience = models.IntegerField()
    age = models.IntegerField()
    phone = models.IntegerField()
    email = models.CharField(max_length=50)
    gender = models.CharField(max_length=50)
    doctor_details = models.CharField(max_length=50)
    address = models.CharField(max_length=100)
    # profile_pic= models.ImageField(upload_to='profile_pic/DoctorProfilePic/',null=True,blank=True)

    def __str__(self):
        return self.doctor_name
    
